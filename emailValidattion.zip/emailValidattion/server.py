from flask import Flask, request, redirect, render_template, session, flash
from mysqlconnection import MySQLConnector
app = Flask(__name__)
mysql = MySQLConnector(app,'mydb')

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/process', methods=['POST'])
def process():
    emails = mysql.query_db("SELECT email FROM emails")
    inputEmails = request.form['email']
    for x in emails:
        if x['email'] == inputEmails:
            query = "INSERT INTO emails(email, created_at, updated_at)VALUES(:email, NOW(), NOW())"
            data = {'email': request.form['email']}
            mysql.query_db(query,data)
            allEmails = mysql.query_db("SELECT * FROM emails")
            return render_template('/valid.html', validEmail = request.form['email'], all_emails = allEmails)
    return render_template('index.html', invalid = "Email is Not Valid!")
        
app.run(debug=True)